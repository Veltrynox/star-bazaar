"""Procedural Star Bazaar orbital trading station. Requires trimesh, numpy.
Exports GLB and OBJ/MTL. Units: metres. Z is station's vertical axis.
"""
import numpy as np, trimesh, math, os
from trimesh.transformations import rotation_matrix
OUT=os.path.dirname(os.path.abspath(__file__))
scene=trimesh.Scene()
COL={
 'paper':[218,217,206,255], 'panel':[155,158,156,255], 'ink':[31,34,39,255],
 'steel':[77,82,88,255], 'mid':[112,119,122,255], 'gold':[210,158,88,255],
 'amber':[143,91,42,255], 'light':[255,196,104,255], 'glass':[51,73,86,255],
 'fuel':[191,185,168,255], 'rust':[114,91,75,255], 'red':[206,75,55,255]
}
counts={}
def add(mesh, material, name):
 mesh.visual.vertex_colors=np.tile(np.array(COL[material],dtype=np.uint8),(len(mesh.vertices),1))
 idx=counts.get(name,0);counts[name]=idx+1
 scene.add_geometry(mesh,geom_name=f'{name}_{idx:03d}',node_name=f'{name}_{idx:03d}')
def box(pos,size,mat,name,angle=0):
 m=trimesh.creation.box(extents=size)
 if angle: m.apply_transform(rotation_matrix(angle,[0,0,1]))
 m.apply_translation(pos);add(m,mat,name)
def cyl(pos,radius,height,mat,name,sections=32):
 m=trimesh.creation.cylinder(radius=radius,height=height,sections=sections);m.apply_translation(pos);add(m,mat,name)
def ring(radius,width,height,z,mat,name,n=64):
 # true hollow ring as section wedges, each segment is a separate triangular prism body
 r0=radius-width/2;r1=radius+width/2
 for i in range(n):
  a=2*np.pi*i/n;b=2*np.pi*(i+1)/n
  # four-sided annulus segment using planar annulus quad extruded
  v=np.array([[r0*np.cos(a),r0*np.sin(a)],[r1*np.cos(a),r1*np.sin(a)],
              [r1*np.cos(b),r1*np.sin(b)],[r0*np.cos(b),r0*np.sin(b)]])
  bottom=np.column_stack((v,np.full(4,z-height/2)))
  top=np.column_stack((v,np.full(4,z+height/2)))
  vv=np.vstack([bottom,top])
  faces=[[0,2,1],[0,3,2],[4,5,6],[4,6,7]]
  for j in range(4):
   k=(j+1)%4;faces.extend([[j,k,k+4],[j,k+4,j+4]])
  m=trimesh.Trimesh(vertices=vv,faces=faces,process=False)
  add(m,mat,name)
def spoke(rad,ang,z,length,width,height,mat,name):
 x=rad*np.cos(ang);y=rad*np.sin(ang)
 box((x,y,z),(length,width,height),mat,name,ang)
def antenna(x,y,z,h):
 cyl((x,y,z+h/2),5,h,'steel','communications_mast',12)
 cyl((x,y,z+h),10,12,'red','navigation_beacon',12)
# central command + commercial core
cyl((0,0,0),310,220,'ink','central_core')
cyl((0,0,115),355,80,'panel','marketplace_mid_deck')
cyl((0,0,-150),370,72,'steel','central_lower_deck')
for z,r,h,mat in [(210,260,85,'paper'),(285,210,80,'steel'),(345,150,60,'panel'),(405,90,60,'ink')]:cyl((0,0,z),r,h,mat,'command_tower')
for z,r,w in [(-220,410,30),(-95,340,26),(65,340,28),(173,370,34),(260,275,25)]:ring(r,w,12,z,'gold','gold_trim',48)
# windows around marketplace stacked decks
for level in range(5):
 z=-85+level*44
 for j in range(48):
  a=j*2*np.pi/48
  x=318*np.cos(a);y=318*np.sin(a)
  box((x,y,z),(32,9,17),'light','marketplace_illuminated_window',a)
# two truly concentric rings
ring(750,165,115,5,'ink','inner_commerce_ring',72)
ring(1030,155,125,-20,'panel','outer_logistics_ring',96)
for radius,z in [(750,70),(750,-58),(1030,53),(1030,-93)]:
 ring(radius,12,10,z,'gold','ring_trim',96)
for radius in [750,1030]:
 for j in range(64):
  a=j*2*np.pi/64
  box((radius*np.cos(a),radius*np.sin(a),24),(35,7,9),'light','ring_running_lights',a)
# major radial structural connections between core and both rings
for k in range(12):
 a=2*np.pi*k/12
 spoke(525,a,-8,480,75,65,'steel','inner_radial_truss')
 spoke(890,a,-20,240,62,55,'steel','outer_radial_truss')
 for r in [410,610,850]:
  spoke(r,a,-46,45,105,15,'gold','radial_cross_brace')
# 16 berths: eight per orbital zone / staggered angular positions
for k in range(16):
 a=2*np.pi*k/16
 radius=1150
 px=radius*np.cos(a);py=radius*np.sin(a)
 # docking arm runs radially beyond outer ring
 spoke(1180,a,-48,430,100,58,'steel','docking_arm')
 spoke(1395,a,-34,135,245,76,'panel','docking_berth_platform')
 spoke(1388,a,12,150,27,16,'gold','berth_centerline')
 for offset in [-93,93]:
  x=1395*np.cos(a)-offset*np.sin(a)
  y=1395*np.sin(a)+offset*np.cos(a)
  box((x,y,24),(140,23,88),'ink','docking_clamp_rail',a)
  spoke(1430,a,70,32,28,118,'paper','berth_pylon') if offset==93 else None
 # airlock at ring-side of berth
 spoke(1080,a,-10,100,120,110,'paper','docking_airlock')
 # yellow amber guidance panels
 for rr in [1240,1330,1450]:
  box((rr*np.cos(a),rr*np.sin(a),13),(28,12,9),'light','berth_guidance_light',a)
 # berth digits as geometry-coded twin panel marks; no raster typography
 for p in range(3):
  box((1450*np.cos(a)-((p-1)*19)*np.sin(a),1450*np.sin(a)+((p-1)*19)*np.cos(a),80),(17,11,10),'gold',f'berth_{k+1:02d}_identifier',a)
# cargo clusters at cardinal offsets
for k in [1,3,5,7,9,11,13,15]:
 a=2*np.pi*k/16
 rr=905
 xx=rr*np.cos(a); yy=rr*np.sin(a)
 box((xx,yy,120),(195,140,120),'paper','cargo_warehouse',a)
 box((xx,yy,187),(175,118,19),'ink','cargo_warehouse_roof',a)
 for j in range(3):
  dx=(j-1)*53
  box((xx+dx*np.cos(a),yy+dx*np.sin(a),204),(35,100,22),'gold','cargo_storage_container',a)
 antenna(xx,yy,220,70)
# fuel storage and service clusters near rings
for a in [np.pi/6,5*np.pi/6,7*np.pi/6,11*np.pi/6]:
 cx=570*np.cos(a);cy=570*np.sin(a)
 box((cx,cy,-95),(260,210,36),'steel','fuel_service_base',a)
 for s in [-75,0,75]:
  x=cx-s*np.sin(a);y=cy+s*np.cos(a)
  cyl((x,y,-10),26,130,'fuel','fuel_reservoir',20)
  cyl((x,y,61),29,13,'gold','fuel_reservoir_band',20)
# grouped residential and station services modules
for k in range(8):
 a=2*np.pi*(k+.5)/8
 r=545; x=r*np.cos(a); y=r*np.sin(a)
 box((x,y,124),(210,135,155),'panel','habitation_module',a)
 box((x,y,209),(222,150,20),'ink','habitation_module_roof',a)
 for level in range(3):
  box((x,y,76+level*45),(204,142,9),'light','habitation_window_band',a)
# hangar terminals four heavy radial service ramps
for k in range(4):
 a=(k+.5)*np.pi/2
 spoke(595,a,-195,610,245,65,'steel','primary_cargo_approach')
 spoke(600,a,-150,585,15,14,'gold','primary_cargo_lane_light')
 spoke(365,a,-95,155,230,180,'paper','major_hangar_portal')
# cranes distributed around logistics ring
for k in range(8):
 a=2*np.pi*(k+.33)/8
 x=1020*np.cos(a);y=1020*np.sin(a)
 box((x,y,125),(18,18,165),'gold','cargo_crane_tower')
 box((x,y,218),(220,15,16),'gold','cargo_crane_jib',a)
 box((x,y,183),(9,9,64),'steel','cargo_crane_cable')
# antennas around central tower
for k in range(10):
 a=2*np.pi*k/10
 antenna(225*np.cos(a),225*np.sin(a),350,180 if k%2==0 else 110)
antenna(0,0,445,240)
# underside machinery/radiators
for k in range(12):
 a=2*np.pi*k/12
 r=590
 x=r*np.cos(a);y=r*np.sin(a)
 box((x,y,-165),(185,80,130),'ink','underdeck_power_module',a)
 for p in [-40,0,40]:
  box((x-p*np.sin(a),y+p*np.cos(a),-236),(120,7,28),'gold','thermal_radiator',a)
# export glb with vertex colors
path_glb=os.path.join(OUT,'star_bazaar_station.glb')
with open(path_glb,'wb') as f:f.write(scene.export(file_type='glb'))
# OBJ export with MTL from trimesh, vertex-color compatibility varies
from trimesh.exchange import obj
objdata=obj.export_obj(scene,include_normals=True,include_color=True,return_texture=False)
with open(os.path.join(OUT,'star_bazaar_station.obj'),'w') as f:f.write(objdata)
print('Geometries',len(scene.geometry),'faces',sum(len(m.faces) for m in scene.geometry.values()))
print('Exported',path_glb)
